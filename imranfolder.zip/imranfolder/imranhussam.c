   void servo_rotate(int pulse_width);
void interrupt (void);
void PWM(unsigned int p, unsigned int d);
void PWM1(unsigned int p, unsigned int d);

unsigned int limit = 20;
void PWMdelay(unsigned int d, unsigned int speed);
void mymsdelay(unsigned int d);
void delay_2s();
void ADC_intit(void){
ADCON1 = 0XCE;
ADCON0 = 0X41;
TRISA = 0X01;

}

unsigned int read_sensor(void) {
unsigned int read;
ADCON0 = ADCON0 | 0X04;
while (ADCON0 & 0X04);
//read = (ADRESH << 8) | 10
return read;
}





void main()
{

    unsigned int speed = 50;
    INTCON = INTCON | 0x90;
    OPTION_REG = OPTION_REG & 0xBF;
    TRISD = 0x00;
    TRISA = 0X01;
    TRISE = 0X00;
    TRISC = 0X06;
    PORTC =0x00;
    TRISB = 0x01;
    PORTB = 0x00;
    //ADC_intit();

    while (1)
    {

    unsigned int r;



    while (!(PORTC & 0x02)){
          PORTD = 0x01;
    }
         while (!(PORTC & 0x04)){
               PORTD = 0x04;
         }
    PWM(10, speed);



    }
}

void interrupt (void)
{
    unsigned int speed1 = 70;
    PORTD = 0x00;
    delay_ms(2000);
    PWMdelay(150,speed1);
    servo_rotate(400);
    INTCON = INTCON & 0xFD;
}


void PWM(unsigned int p, unsigned int d) {
    unsigned int period = p;
    unsigned int duty = (d * p) / 100;

    unsigned int i;
    for (i = 0; i < period; i++) {
        if (i < duty) {
            PORTD = 0x05;
        } else {
            PORTD = 0x00;
        }
        delay_ms(1);
    }
}

void PWM1(unsigned int p, unsigned int d) {
    unsigned int period = p;
    unsigned int duty = (d * p) / 100;

    unsigned int i;
    for (i = 0; i < period; i++) {
        if (i < duty) {
            PORTD = 0x05;
        } else {
            PORTD = 0x00;
        }
        delay_ms(1);
    }
}

void servo_rotate(int pulse_width)
{
    unsigned int i;
    unsigned int x;

    for (i = 0; i < pulse_width; i++)
    {
        PORTC = 0x01;
        delay_ms(1);
        PORTC = 0x00;
        delay_ms(19);
    }
}

void PWMdelay(unsigned int d, unsigned int speed){
unsigned int cntr=0;
while(cntr < d){
PWM1(10,speed);

   cntr++;
}
}

void mymsdelay(unsigned int d) {
    unsigned int cntr = 0;
        while (cntr < d) {
        cntr=cntr;
            cntr++;
        }
}
 void delay_2s() {
    unsigned int i, j;


    for (i = 0; i < 2000; i++) {
        for (j = 0; j < 100; j++) {
           asm{NOP};
        }
    }
}